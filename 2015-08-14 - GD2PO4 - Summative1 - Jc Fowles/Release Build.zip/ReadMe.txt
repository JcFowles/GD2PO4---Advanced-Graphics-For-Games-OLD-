/**********************/Summative1\**********************\
   \******************\Vertex Shader/*****************/

***About***

- Using the vertex buffer and index buffer create a grid.
  Create a random function for the y positions of the grid
  so that the grid looks like a terrain
- The terrain is coloured as a function of time. 
  The colouring should take place through the vertex shader.
- The terrain should not be rotating in any axis
- The user can control the camera and move it around the terrain.


Movements:


Camera Movement:
[NUMPAD_8]	-> 	Moves camera forward.	- On Look Vector.
[NUMPAD_2]	-> 	Moves camera Backward.	- On Look Vector.
[NUMPAD_4]	-> 	Strafes camera Left	- On Right Vector.
[NUMPAD_6]	-> 	Strafes camera Right.	- On Left Vector.
[NUMPAD_1]	-> 	Fly camera Up.		- On Up Vector.
[NUMPAD_0]	-> 	Fly camera Down.	- On Up Vector.

Camera Rotation:
[ARROW_UP]	->	Pitch Camera Up.
[ARROW_DOWN]	->	Pitch Camera Down.
[ARROW_LEFT]	->	Yaw camera Left.
[ARROW_RIGHT]	->	Yaw camera Right.


***Known Bugs***

No Knows Bugs


***Credits***
Author: Jc Fowles
Company: Media Design School
Date: 14/08/2015